import React from "react";
import "./Fondo.css";

const Fondo: React.FC = () => {
  return (
    <section className="fondo">
          <div className="fondo-img fondo-img-1"></div>
    </section>
  );
};

export default Fondo;