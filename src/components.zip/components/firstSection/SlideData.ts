export const SlideData = [
  {
    alt: "TAUARI SOUTH BEACH",
    srcSet: {
      "1x1": "https://res.cloudinary.com/drwacbtjf/image/upload/v1745075306/1.1_hdkopb_1_1_eqsh8q.png",
      "4x5": "https://res.cloudinary.com/drwacbtjf/image/upload/v1745075316/4.5_eh6me1_1_1_odsvol.png",
      "9x16": "https://res.cloudinary.com/drwacbtjf/image/upload/v1745075313/9.16_xnrdrf_1_1_z7eiae.png",
      "4x3": "https://res.cloudinary.com/drwacbtjf/image/upload/v1745075296/4.3_o6p5ke_1_1_n0vtax.png",
      "3x2": "https://res.cloudinary.com/drwacbtjf/image/upload/v1745075294/3.2_asfbbf_1_1_a3vrwa.png",
      "16x9": "https://res.cloudinary.com/drwacbtjf/image/upload/v1742920360/firstsection4_eb9qfy.jpg"
    }
  },
  {
    alt: "TAUARI SOUTH BEACH",
    srcSet: {
      "1x1": "https://res.cloudinary.com/drwacbtjf/image/upload/v1745074944/1.1_hles8z_1_1_xs3i5c.png",
      "4x5": "https://res.cloudinary.com/drwacbtjf/image/upload/v1745074938/4.5_xr5ttm_1_1_q983og.png",
      "9x16": "https://res.cloudinary.com/drwacbtjf/image/upload/v1745074929/9.16_hkidw0_1_1_mzpb2r.png",
      "4x3": "https://res.cloudinary.com/drwacbtjf/image/upload/v1745074935/4.3_yejvxg_1_1_xxd5wu.png",
      "3x2": "https://res.cloudinary.com/drwacbtjf/image/upload/v1745074941/3.2_auqims_1_1_wn9fj6.png",
      "16x9": "https://res.cloudinary.com/drwacbtjf/image/upload/v1742920359/firstsection2_vvtaae.jpg"
    }
  },
  {
    alt: "TAUARI SOUTH BEACH",
    srcSet: {
      "1x1": "https://res.cloudinary.com/drwacbtjf/image/upload/v1745076014/1.1_mesrqu_1_toxjwe.png",
      "4x5": "https://res.cloudinary.com/drwacbtjf/image/upload/v1745076005/4.5_nftogz_1_o7noix.png",
      "9x16": "https://res.cloudinary.com/drwacbtjf/image/upload/v1745076011/9.16_mnnhbv_1_kwala6.png",
      "4x3": "https://res.cloudinary.com/drwacbtjf/image/upload/v1745076001/4.3_ebenev_1_xt6aze.png",
      "3x2": "https://res.cloudinary.com/drwacbtjf/image/upload/v1745075997/3.2_l0yztq_1_xc6tjl.png",
      "16x9": "https://res.cloudinary.com/drwacbtjf/image/upload/v1742920359/firstsection3_e4au5x.jpg"
    }
  },  
  {
    alt: "TAUARI SOUTH BEACH",
    srcSet: {
      "1x1": "https://res.cloudinary.com/drwacbtjf/image/upload/v1745075580/1.1_wnoour_1_gcmmjn.png",
      "4x5": "https://res.cloudinary.com/drwacbtjf/image/upload/v1745075588/4.5_pkpxdh_1_bpbqfm.png",
      "9x16": "https://res.cloudinary.com/drwacbtjf/image/upload/v1745075592/9.16_p0silx_1_klv0nl.png",
      "4x3": "https://res.cloudinary.com/drwacbtjf/image/upload/v1745075584/4.3_jdbtd1_1_u3vil5.png",
      "3x2": "https://res.cloudinary.com/drwacbtjf/image/upload/v1745075600/3.2_ijhhpg_1_vhadxx.png",
      "16x9": "https://res.cloudinary.com/drwacbtjf/image/upload/v1744659060/escalera_cm3lbb.jpg"
    }
  }
];
