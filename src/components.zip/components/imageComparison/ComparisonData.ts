export const comparisonData = [
  {
    before: "https://res.cloudinary.com/drwacbtjf/image/upload/v1742854747/Imagen_de_WhatsApp_2025-02-06_a_las_18.38.14_023dbe16_ylkdxr.jpg",
    after: "https://res.cloudinary.com/drwacbtjf/image/upload/v1742854663/Imagen_de_WhatsApp_2025-02-06_a_las_18.38.13_e9174645_lgkbqk.jpg",
    alt: "Dust II - CT Ramp",
  },
  {
    before: "https://res.cloudinary.com/drwacbtjf/image/upload/v1742854491/Imagen_de_WhatsApp_2025-02-06_a_las_18.38.13_183997cd_qypyal.jpg",
    after: "https://res.cloudinary.com/drwacbtjf/image/upload/v1742854491/Imagen_de_WhatsApp_2025-02-06_a_las_18.38.13_3294c619_mqj5ug.jpg",
    alt: "Living",
  },
  {
    before: "https://res.cloudinary.com/drwacbtjf/image/upload/v1742921699/living1_cdkagq.jpg",
    after: "https://res.cloudinary.com/drwacbtjf/image/upload/v1742921850/living2_tzjvsr.jpg",
    alt: "Living",
  },
];
