import React, { useEffect, useState } from "react";
import styles from "./OpinionesCarousel.module.css";
import { EmbeddedReview } from "./types";
import { FacebookIframeCard } from "./FacebookIframeCard";

interface Props {
  reviews: EmbeddedReview[];
  itemsPerSlide?: number;
  autoSlideInterval?: number;
  title?: string;
}

const chunkArray = (array: EmbeddedReview[], size: number): EmbeddedReview[][] =>
  array.reduce<EmbeddedReview[][]>((acc, _, index) =>
    index % size === 0 ? [...acc, array.slice(index, index + size)] : acc, []);

const OpinionesCarousel: React.FC<Props> = ({
  reviews,
  itemsPerSlide = 3,
  autoSlideInterval = 5000,
  title = "¡Clientes felices!"
}) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const reviewGroups = chunkArray(reviews, itemsPerSlide);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % reviewGroups.length);
    }, autoSlideInterval);
    return () => clearInterval(interval);
  }, [reviewGroups.length, autoSlideInterval]);

  const handlePrev = () => setCurrentSlide((prev) => (prev - 1 + reviewGroups.length) % reviewGroups.length);
  const handleNext = () => setCurrentSlide((prev) => (prev + 1) % reviewGroups.length);

  return (
    <section className={styles.opinionesSection}>
      <h2>{title}</h2>
      {reviewGroups.length > 0 ? (
        <div className={styles.carouselContainer}>
          <div className={styles.opinionesGrid}>
            {reviewGroups[currentSlide].map((rev) => (
              <FacebookIframeCard key={rev.id} iframeSrc={rev.iframeSrc} onClick={handleNext} />
            ))}
          </div>
          <button className={styles.carouselControlPrev} onClick={handlePrev}>❮</button>
          <button className={styles.carouselControlNext} onClick={handleNext}>❯</button>
        </div>
      ) : (
        <p className="text-center">Aún no hay comentarios.</p>
      )}
    </section>
  );
};

export default OpinionesCarousel;
